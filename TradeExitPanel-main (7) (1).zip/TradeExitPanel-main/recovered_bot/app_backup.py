from datetime import datetime, timezone, timedelta
import os
import time
import threading
import requests
import pandas as pd
from telegram import TelegramNotifier
from strategy import ABCDStrategy
from paper_trader import open_paper_trade, paper_trade_monitor_loop

BOT_TOKEN = os.getenv("BOT_TOKEN", "8994572465:AAHyScKAq_V0FzVYnijJvOBuvMws2RbrRck")
CHAT_ID = os.getenv("CHAT_ID", "885150597")
REST_BASE = "https://fapi.binance.com/fapi/v1"
WATCHLIST_REFRESH_INTERVAL = 60
POLL_INTERVAL = 15
INITIAL_HISTORY_LIMIT = 250

bot = TelegramNotifier(bot_token=BOT_TOKEN, chat_id=CHAT_ID)
strategy = ABCDStrategy()
watchlist = set()
history_cache = {}
lock = threading.Lock()
sent_signals = set()
signal_count_today = 0
signal_count_date = None
BOT_START_TIME = int(time.time() * 1000)

def fetch_initial_history(symbol: str) -> pd.DataFrame:
    url = f"{REST_BASE}/klines"
    params = {"symbol": symbol, "interval": "3m", "limit": INITIAL_HISTORY_LIMIT}
    try:
        resp = requests.get(url, params=params, timeout=10)
        data = resp.json()
        if not isinstance(data, list) or len(data) == 0:
            return pd.DataFrame()
        df = pd.DataFrame(data, columns=['timestamp','open','high','low','close','volume','close_time','quote_asset_volume','number_of_trades','taker_buy_base_asset_volume','taker_buy_quote_asset_volume','ignore'])
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        df.set_index('timestamp', inplace=True)
        return df
    except Exception:
        return pd.DataFrame()

def get_current_movers():
    try:
        ticker_data = requests.get(f"{REST_BASE}/ticker/24hr", timeout=10).json()
        if not isinstance(ticker_data, list):
            return [], []
        valid_pairs = [t for t in ticker_data if t['symbol'].endswith('USDT') and float(t['quoteVolume']) > 5000000]
        valid_pairs.sort(key=lambda x: float(x['priceChangePercent']), reverse=True)
        gainers = [d['symbol'] for d in valid_pairs[:10]]
        losers = [d['symbol'] for d in valid_pairs[-10:]]
        return gainers, losers
    except Exception as e:
        print(f"[Error] Movers: {e}")
        return [], []

def refresh_watchlist():
    global watchlist
    while True:
        try:
            gainers, losers = get_current_movers()
            new_list = list(dict.fromkeys(gainers + losers))
            with lock:
                for sym in new_list:
                    if sym not in history_cache:
                        df = fetch_initial_history(sym)
                        if not df.empty:
                            history_cache[sym] = df
                            print(f"[History] Seeded {sym}")
                watchlist = set(new_list)
            print(f"[{time.strftime('%H:%M:%S')}] [Watchlist] Updated to {len(watchlist)} symbols")
        except Exception as e:
            print(f"[Watchlist] Error: {e}")
        time.sleep(WATCHLIST_REFRESH_INTERVAL)

def process_candle(symbol: str, kline_data: dict):
    close_time = kline_data['t']
    candle_key = f"{symbol}-{close_time}"
    if candle_key in sent_signals:
        return
    if close_time < BOT_START_TIME:
        return
    with lock:
        if symbol not in history_cache or len(history_cache[symbol]) == 0:
            history_cache[symbol] = fetch_initial_history(symbol)
        else:
            df = history_cache[symbol]
            if df.index[-1] != pd.to_datetime(close_time, unit='ms'):
                new_row = {'timestamp': pd.to_datetime(kline_data['t'], unit='ms'), 'open': float(kline_data['o']), 'high': float(kline_data['h']), 'low': float(kline_data['l']), 'close': float(kline_data['c']), 'volume': float(kline_data['v'])}
                df = pd.concat([df, pd.DataFrame([new_row]).set_index('timestamp')]).tail(INITIAL_HISTORY_LIMIT)
                history_cache[symbol] = df

    signal = strategy.generate_signal(history_cache[symbol], symbol)

    if signal:
        try:
            ticker = requests.get(f"{REST_BASE}/ticker/24hr", params={"symbol": signal.symbol}, timeout=10).json()
            pct_change = float(ticker.get('priceChangePercent', 0))
        except:
            pct_change = 0.0

        ist_time = datetime.fromtimestamp(close_time / 1000, tz=timezone.utc) + timedelta(hours=5, minutes=30)
        ist_str = ist_time.strftime("%d %b, %I:%M %p")
        ist_date = ist_time.strftime("%d %b %Y")

        global signal_count_today, signal_count_date
        if signal_count_date != ist_date:
            signal_count_date = ist_date
            signal_count_today = 0
        signal_count_today += 1

        alert_data = {
            "signal_no": signal_count_today,
            "signal_date": ist_date,
            "action": signal.action, "symbol": signal.symbol, "entry_price": signal.entry_price,
            "stop_loss": signal.stop_loss, "tp1": signal.tp1, "tp2": signal.tp2,
            "tp3": signal.tp3, "tp4": signal.tp4, "sz_zone": "N/A",
            "signal_time_utc": signal.signal_time, "signal_time_local": signal.signal_time,
            "signal_time_ist": ist_str,
            "category": "Current Top Movers", "pct_change": pct_change
        }
        bot.send_detailed_alert(alert_data)
        open_paper_trade(signal, bot)
        sent_signals.add(candle_key)
        print(f"[{time.strftime('%H:%M:%S')}] [SIGNAL] {signal.symbol} {signal.action} at {signal.entry_price}")
    else:
        print(f"[{time.strftime('%H:%M:%S')}] {symbol}: Candle close hui, signal nahi mila.")

def poll_klines():
    while True:
        with lock:
            symbols = list(watchlist)
        for symbol in symbols:
            try:
                url = f"{REST_BASE}/klines"
                params = {"symbol": symbol, "interval": "3m", "limit": 2}
                resp = requests.get(url, params=params, timeout=10)
                data = resp.json()
                if isinstance(data, list) and len(data) >= 2:
                    last_closed = data[-2]
                    kline_data = {
                        't': last_closed[0], 'o': last_closed[1], 'h': last_closed[2],
                        'l': last_closed[3], 'c': last_closed[4], 'v': last_closed[5]
                    }
                    process_candle(symbol, kline_data)
            except Exception as e:
                print(f"[Poll] {symbol} error: {e}")
        time.sleep(POLL_INTERVAL)

def heartbeat():
    while True:
        time.sleep(60)
        print(f"[{time.strftime('%H:%M:%S')}] [Heartbeat] Bot zinda hai! Total symbols: {len(watchlist)}")

def main():
    print("Starting bot (REST polling mode)...")
    threading.Thread(target=heartbeat, daemon=True).start()
    threading.Thread(target=refresh_watchlist, daemon=True).start()
    threading.Thread(target=paper_trade_monitor_loop, args=(bot,), daemon=True).start()
    poll_klines()

if __name__ == "__main__":
    main()
