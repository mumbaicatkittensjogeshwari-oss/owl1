[app]
title = Trade Exit Panel
package.name = tradeexitpanel
package.domain = org.tradeexit
source.dir = .
source.main = main.py
version = 0.1

requirements = python3==3.10.11,hostpython3==3.10.11,kivy,requests==2.25.1,chardet==4.0.0,idna==2.10,urllib3==1.26.15,certifi,websocket-client

orientation = portrait
fullscreen = 0

android.api = 34
android.minapi = 24
android.archs = arm64-v8a
android.permissions = INTERNET,ACCESS_NETWORK_STATE,WAKE_LOCK
android.entrypoint = org.kivy.android.PythonActivity
android.allow_backup = False

p4a.bootstrap = sdl2
android.p4a_sdl2_version = 2.28.5
android.accept_sdk_license = True

warn_on_root = 0
