"""Manual Telegram send test - run from Termux to confirm your bot token/chat
ID work. SECURITY: do not hardcode your token here. Set it as an environment
variable before running, e.g. in Termux:
    export BOT_TOKEN="your_new_rotated_token"
    export CHAT_ID="your_chat_id"
    python test_telegram.py
"""
import os
import requests

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
CHAT_ID = os.getenv("CHAT_ID", "")

if not BOT_TOKEN or not CHAT_ID:
    print("Set BOT_TOKEN and CHAT_ID environment variables first (see comment at top of this file).")
else:
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    payload = {"chat_id": CHAT_ID, "text": "Test message from Termux - Telegram is working!"}
    resp = requests.post(url, data=payload, timeout=10)
    print("Status code:", resp.status_code)
    print("Response:", resp.text)
